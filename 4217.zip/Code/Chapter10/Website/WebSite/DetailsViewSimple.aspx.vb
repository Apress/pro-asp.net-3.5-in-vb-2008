
Partial Class DetailsViewSimple
    Inherits System.Web.UI.Page

End Class
