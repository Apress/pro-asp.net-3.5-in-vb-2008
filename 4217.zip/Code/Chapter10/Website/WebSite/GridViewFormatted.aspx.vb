
Partial Class GridViewFormatted
    Inherits System.Web.UI.Page

End Class
