
Partial Class FormViewSimple
    Inherits System.Web.UI.Page

End Class
