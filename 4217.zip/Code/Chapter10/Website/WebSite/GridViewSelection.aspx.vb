
Partial Class GridViewSelection
    Inherits System.Web.UI.Page

End Class
