
Partial Class ListViewTemplates
    Inherits System.Web.UI.Page

End Class
