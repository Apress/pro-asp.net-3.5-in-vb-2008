
Partial Class EditRelatedDataWithList
    Inherits System.Web.UI.Page

    'Protected Sub detailsProducts_PageIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles detailsProducts.PageIndexChanged
    '    detailsProducts.ChangeMode(DetailsViewMode.ReadOnly)
    'End Sub
    Protected Sub DetailsView1_PageIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        detailsProducts.ChangeMode(DetailsViewMode.[ReadOnly])
    End Sub
End Class
