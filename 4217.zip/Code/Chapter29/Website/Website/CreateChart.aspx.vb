﻿Imports System.Collections.Generic

Partial Class CreateChart
    Inherits System.Web.UI.Page
    ' The data that will be used to create the pie chart.
    Private pieSlices As List(Of PieSlice) = New List(Of PieSlice)()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Retrieve the pie slices that are defined so far.
        If Session("ChartData") IsNot Nothing Then
            pieSlices = DirectCast(Session("ChartData"), List(Of PieSlice))
        End If
    End Sub

    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
        ' Create a new pie slice.
        Dim pieSlice As New PieSlice(txtLabel.Text, Single.Parse(txtValue.Text))
        pieSlices.Add(pieSlice)

        ' Bind the list box to the new data.
        lstPieSlices.DataSource = pieSlices
        lstPieSlices.DataBind()

    End Sub
    Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
        ' Before rendering the page, store the current collection
        ' of pie slices.
        Session("ChartData") = pieSlices
    End Sub
End Class
