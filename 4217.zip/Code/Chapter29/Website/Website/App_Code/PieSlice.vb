﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Data
Imports System.Configuration
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Xml.Linq

Public Class PieSlice
    Private _dataValue As Single
    Private _caption As String

    Public Property DataValue() As Single
        Get
            Return _dataValue
        End Get
        Set(ByVal value As Single)
            _dataValue = value
        End Set
    End Property
    Public Property Caption() As String
        Get
            Return _caption
        End Get
        Set(ByVal value As String)
            _caption = value
        End Set
    End Property
    Public Sub New(ByVal caption As String, ByVal dataValue As Single)
        _caption = caption
        _dataValue = dataValue
    End Sub
    Public Overrides Function ToString() As String
        Return Caption + " (" + _dataValue.ToString() + ")"
    End Function
End Class
