﻿Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.ComponentModel
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Web

Namespace GDI_CustomControls
    Public Class GradientLabel
        Inherits Control

        Public Sub New()
            Text = ""
            TextColor = Color.White
            GradientColorStart = Color.Blue
            GradientColorEnd = Color.DarkBlue
            TextSize = 14
        End Sub
        Public Property Text() As String
            Get
                Return ViewState("Text").ToString()
            End Get
            Set(ByVal value As String)
                ViewState("Text") = value
            End Set
        End Property
        Public Property TextSize() As Integer
            Get
                Return DirectCast(ViewState("TextSize"), Integer)
            End Get
            Set(ByVal value As Integer)
                ViewState("TextSize") = value
            End Set
        End Property
        Public Property GradientcolorStart() As Color
            Get
                Return DirectCast(ViewState("ColorStart"), Color)
            End Get
            Set(ByVal value As Color)
                ViewState("ColorStart") = value
            End Set
        End Property
        Public Property GradientcolorEnd() As Color
            Get
                Return DirectCast(ViewState("ColorEnd"), Color)
            End Get
            Set(ByVal value As Color)
                ViewState("ColorEnd") = value
            End Set
        End Property
        Public Property TextColor() As Color
            Get
                Return DirectCast(ViewState("TextColor"), Color)
            End Get
            Set(ByVal value As Color)
                ViewState("TextColor") = value
            End Set
        End Property
        Protected Overrides Sub Render(ByVal writer As System.Web.UI.HtmlTextWriter)
            Dim content As HttpContext = HttpContext.Current
            writer.Write("<img src='GradientLabel.aspx? Text=" + Context.Server.UrlEncode(Text) + "  TextSize=" + TextSize.ToString() + "  TextColor=" + TextColor.ToArgb() + "  GradientColorStart=" + GradientcolorStart.ToArgb() + " GradientColorEnd=" + GradientcolorEnd.ToArgb() + "'>")
        End Sub
    End Class
End Namespace

