﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Configuration.Install
Imports System.Data.SqlClient
Imports System.Windows.Forms

Namespace Apress.CustomInstaller
    <RunInstaller(True)> _
    Partial Public Class DbInstaller
        Inherits System.Configuration.Install.Installer
        Public Sub New()
            'InitializeComponent()
        End Sub

        Protected Overrides Sub OnBeforeInstall(ByVal savedState As System.Collections.IDictionary)
            MessageBox.Show("Executing custom database action")

            Try
                Dim conn As New SqlConnection()
                conn.ConnectionString = "data source=(local)\SQL2005;integrated security=SSPI;initial catalog=master"
                conn.Open()

                Try
                    ' Create the database 
                    Dim cmd As New SqlCommand()
                    cmd.Connection = conn
                    cmd.CommandText = "CREATE DATABASE TestDb"
                    cmd.ExecuteNonQuery()

                    ' Now close the connection and connect to the created TestDb database to create the tables
                    ' ...
                Finally
                    conn.Close()
                End Try
            Catch ex As Exception
                MessageBox.Show("Exception: " & ex.Message)
                MyBase.Rollback(savedState)
            End Try

            MyBase.OnBeforeInstall(savedState)
        End Sub

        Protected Overrides Sub OnBeforeUninstall(ByVal savedState As System.Collections.IDictionary)
            Try
                Dim conn As New SqlConnection()
                conn.ConnectionString = "data source=(local)\SQL2005;integrated security=SSPI;initial catalog=master"
                conn.Open()

                Try
                    ' Create the database 
                    Dim cmd As New SqlCommand()
                    cmd.Connection = conn
                    cmd.CommandText = "DROP DATABASE TestDb"
                    cmd.ExecuteNonQuery()
                Finally
                    conn.Close()
                End Try
            Catch
                MyBase.Rollback(savedState)
            End Try

            MyBase.OnBeforeUninstall(savedState)
        End Sub
    End Class
End Namespace