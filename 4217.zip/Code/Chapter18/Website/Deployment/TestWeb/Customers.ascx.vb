﻿
Partial Class TestUserControls_Customers
    Inherits System.Web.UI.UserControl
    Implements IWebPart

#Region "IWebPart Members"
    Private _CatalogImageUrl As String
    Public Property CatalogIconImageUrl() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.CatalogIconImageUrl
        Get
            Return _CatalogImageUrl
        End Get
        Set(ByVal value As String)
            _CatalogImageUrl = value
        End Set
    End Property

    Private _Description As String
    Public Property Description() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.Description
        Get
            Return _Description
        End Get
        Set(ByVal value As String)
            _Description = value
        End Set
    End Property

    Public ReadOnly Property Subtitle() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.Subtitle
        Get
            Return "Internal Customer List"
        End Get
    End Property

    Public Property Title() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.Title
        Get
            If ViewState("Title") Is Nothing Then
                Return String.Empty
            Else
                Return ViewState("Title").ToString()
            End If
        End Get
        Set(ByVal value As String)
            ViewState("Title") = value
        End Set
    End Property

    Private _TitleImage As String
    Public Property TitleIconImageUrl() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.TitleIconImageUrl
        Get
            If _TitleImage Is Nothing Then
                Return "~/Files/CustomersSmall.jpg"
            Else
                Return _TitleImage
            End If
        End Get
        Set(ByVal value As String)
            _TitleImage = value
        End Set
    End Property

    Private _TitleUrl As String
    Public Property TitleUrl() As String Implements System.Web.UI.WebControls.WebParts.IWebPart.TitleUrl
        Get
            Return _TitleUrl
        End Get
        Set(ByVal value As String)
            _TitleUrl = value
        End Set
    End Property
#End Region
    Private _MyValue As String = String.Empty

    <Personalizable()> _
    Public Property MyValue() As String
        Get
            Return _MyValue
        End Get
        Set(ByVal value As String)
            _MyValue = value
        End Set
    End Property
End Class
