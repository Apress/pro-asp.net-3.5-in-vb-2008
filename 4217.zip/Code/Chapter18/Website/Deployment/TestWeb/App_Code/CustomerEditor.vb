﻿Imports Microsoft.VisualBasic
Imports System.Web.UI.WebControls.WebParts
Imports CustomersSetTableAdapters

Namespace APress.WebParts.Samples
    Public Class CustomerEditor
        Inherits EditorPart

        Public Sub New()
            AddHandler (Me.Init), New EventHandler(AddressOf CustomerEditor_Init)
        End Sub

        Sub CustomerEditor_Init(ByVal sender As Object, ByVal e As EventArgs)
            EnsureChildControls()

            Dim adapter As New CustomerTableAdapter()
            CustomerList.DataSource = adapter.GetData()
            CustomerList.DataTextField = "CompanyName"
            CustomerList.DataValueField = "CustormerID"
            CustomerList.DataBind()

            CustomerList.Items.Insert(0, "")
        End Sub
        Public Overrides Function ApplyChanges() As Boolean
            ' Make sure that all controls are available
            EnsureChildControls()

            ' Get the property from the WebPart
            Dim part As CustomerNotesPart = DirectCast(WebPartToEdit, CustomerNotesPart)
            If part IsNot Nothing Then
                If CustomerList.SelectedIndex >= 0 Then
                    part.Customer = CustomerList.SelectedValue
                Else
                    part.Customer = String.Empty
                End If
            Else
                Return False
            End If
            Return True
        End Function

        Public Overrides Sub SyncChanges()
            ' Make sure that all controls are available
            EnsureChildControls()

            ' Get the property from the WebPart
            Dim part As CustomerNotesPart = DirectCast(WebPartToEdit, CustomerNotespart)
            If part IsNot Nothing Then
                CustomerList.SelectedValue = part.Customer
            End If
        End Sub

        Private CustomerList As ListBox

        Protected Overrides Sub CreateChildControls()
            'MyBase.CreateChildControls()
            CustomerList = New ListBox()
            CustomerList.Rows = 4
            Controls.Add(CustomerList)
        End Sub
    End Class
End Namespace
