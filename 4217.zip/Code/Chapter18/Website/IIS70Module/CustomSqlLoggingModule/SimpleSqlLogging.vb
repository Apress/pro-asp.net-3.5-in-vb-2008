﻿Imports System.Web
Imports System.Collections.Generic
Imports System.Diagnostics

Namespace CustomSqlLoggingModule
    Public Class SimpleSqlLogging
        Implements IHttpModule

        Private _CurrentApplication As HttpApplication

        Public Sub Dispose() Implements System.Web.IHttpModule.Dispose
            _CurrentApplication = Nothing

        End Sub

        Public Sub Init(ByVal context As HttpApplication) Implements System.Web.IHttpModule.Init
            ' Attach to the incoming request event
            _CurrentApplication = context
            If context IsNot Nothing Then
                AddHandler context.BeginRequest, _
                New EventHandler(AddressOf context_BeginRequest)
            End If
        End Sub
        Sub context_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
            Try
                ' Write a log entry to the database
                Dim adapter As SimpleLoggingDataSetTableAdapters.WebLoggingTableAdapter = _
                New SimpleLoggingDataSetTableAdapters.WebLoggingTableAdapter()

                adapter.Insert(Guid.NewGuid(), _
                               DateTime.Now, _
                _CurrentApplication.Context.Request.Url.ToString(), _
                _CurrentApplication.Context.Request.UserAgent, _
                _CurrentApplication.Context.Request.UserHostAddress)

            Catch ex As Exception
                Debug.WriteLine("Exception: " + ex.Message)
            End Try
        End Sub
    End Class
End Namespace
