﻿
Partial Class DynamicHeader
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.Header.Title = "Dynamically Titled Page"

        ' Define a metadata tag with description information. 
        Dim metaDescription As New HtmlMeta()
        metaDescription.Name = "description"
        metaDescription.Content = "A great website to learn .NET"

        ' Add it. 
        Page.Header.Controls.Add(metaDescription)

        ' Define and add a second metadata tag. 
        Dim metaKeywords As New HtmlMeta()
        metaKeywords.Name = "keywords"
        metaKeywords.Content = ".NET, C#, ASP.NET"
        Page.Header.Controls.Add(metaKeywords)

    End Sub

   
End Class
