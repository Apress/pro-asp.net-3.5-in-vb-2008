﻿
Partial Class CustomTextBoxTest
    Inherits System.Web.UI.Page

    Protected Sub CustomTextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CustomTextBox1.TextChanged
        Response.Write("Changed")
    End Sub
End Class
