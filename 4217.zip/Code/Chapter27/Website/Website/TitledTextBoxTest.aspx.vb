﻿
Partial Class TitledTextBoxTest
    Inherits System.Web.UI.Page

End Class
