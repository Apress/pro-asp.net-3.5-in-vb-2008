﻿
Partial Class SuperSimpleRepeaterTest
    Inherits System.Web.UI.Page

End Class
