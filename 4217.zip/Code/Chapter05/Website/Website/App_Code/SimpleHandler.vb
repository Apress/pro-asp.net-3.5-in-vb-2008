Imports Microsoft.VisualBasic

Imports System
Imports System.Web

Public Class SimpleHandler


    Public Sub ProcessRequest(ByVal context As System.Web.HttpContext)
        Dim response As HttpResponse = context.Response
        response.Write("<html><body><h1>Rendered by the SimpleHandler")
        response.Write("</h1></body></html>")
    End Sub

    Public ReadOnly Property IsReusable() As Boolean
        Get
            Return True
        End Get
    End Property
End Class