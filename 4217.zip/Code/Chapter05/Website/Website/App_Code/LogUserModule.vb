Imports Microsoft.VisualBasic

Imports System
Imports System.Web
Imports System.Diagnostics


Public Class LogUserModule
    Public Sub Init(ByVal httpApp As HttpApplication)
        AddHandler httpApp.AuthenticateRequest, AddressOf OnAuthentication
        ' Attach application event handlers. 
    End Sub

    Private Sub OnAuthentication(ByVal sender As Object, ByVal a As EventArgs)
        ' Get the current user identity. 
        Dim name As String = HttpContext.Current.User.Identity.Name

        ' Log the user name. 
        Dim log As New EventLog()
        log.Source = "Log User Module"

        ' This throws an error in Windows Vista when Visual Studio is not running as an administrator. 
        ' To resolve, right-click the Visual Studio shortcut in the Start menu and choose Run As Administrator. 
        log.WriteEntry(name + " was authenticated.")
    End Sub

    Public Sub Dispose()
    End Sub
End Class