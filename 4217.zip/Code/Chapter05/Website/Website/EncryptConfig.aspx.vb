Imports System.Web.Configuration

Partial Class EncryptConfig
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' This throws an error in Windows Vista when Visual Studio is not running as an administrator. 
        ' To resolve, right-click the Visual Studio shortcut in the Start menu and choose Run As Administrator. 
        Dim config As Configuration = WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath)
        Dim appSettings As ConfigurationSection = config.GetSection("appSettings")

        If appSettings.SectionInformation.IsProtected Then
            appSettings.SectionInformation.UnprotectSection()
        Else
            appSettings.SectionInformation.ProtectSection("DataProtectionConfigurationProvider")
        End If
        config.Save()
        lblInfo.Text = "web.config file saved with encrypted appSettings section."

    End Sub
End Class
