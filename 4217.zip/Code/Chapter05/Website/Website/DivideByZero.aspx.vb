
Partial Class DivideByZero
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim k As Integer = j / i
    End Sub
End Class
