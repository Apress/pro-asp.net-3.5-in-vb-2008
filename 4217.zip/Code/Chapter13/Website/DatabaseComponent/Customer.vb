﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Data.Linq
Imports System.Data.Linq.Mapping

Namespace DatabaseComponent.Simplified
    <Table(Name:="dbo.Customers")> _
    Public Class Customer
        Private privateCustomerID As String
        <Column(IsPrimaryKey:=True)> _
        Public Property CustomerID() As String
            Get
                Return privateCustomerID
            End Get
            Set(ByVal value As String)
                privateCustomerID = value
            End Set
        End Property

        Private privateCompanyName As String
        <Column()> _
        Public Property CompanyName() As String
            Get
                Return privateCompanyName
            End Get
            Set(ByVal value As String)
                privateCompanyName = value
            End Set
        End Property

        Private privateContactName As String
        <Column()> _
        Public Property ContactName() As String
            Get
                Return privateContactName
            End Get
            Set(ByVal value As String)
                privateContactName = value
            End Set
        End Property

        Private privateContactTitle As String
        <Column()> _
        Public Property ContactTitle() As String
            Get
                Return privateContactTitle
            End Get
            Set(ByVal value As String)
                privateContactTitle = value
            End Set
        End Property

        Private orders_Renamed As EntitySet(Of Order)

        <Association(Storage:="orders", OtherKey:="CustomerID", ThisKey:="CustomerID")> _
        Public Property Orders() As EntitySet(Of Order)
            Get
                Return orders_Renamed
            End Get
            Set(ByVal value As EntitySet(Of Order))
                orders_Renamed.Assign(value)
            End Set
        End Property
    End Class

    <Table(Name:="dbo.Orders")> _
    Public Class Order
        Private privateOrderID As Integer
        <Column(IsPrimaryKey:=True, IsDbGenerated:=True)> _
        Public Property OrderID() As Integer
            Get
                Return privateOrderID
            End Get
            Set(ByVal value As Integer)
                privateOrderID = value
            End Set
        End Property

        Private privateCustomerID As String
        <Column()> _
        Public Property CustomerID() As String
            Get
                Return privateCustomerID
            End Get
            Set(ByVal value As String)
                privateCustomerID = value
            End Set
        End Property

        Private privateOrderDate As Nullable(Of DateTime)
        <Column()> _
        Public Property OrderDate() As Nullable(Of DateTime)
            Get
                Return privateOrderDate
            End Get
            Set(ByVal value As Nullable(Of DateTime))
                privateOrderDate = value
            End Set
        End Property

        Private _Customer As EntityRef(Of Customer)
        <Association(Name:="FK_Orders_Customers", Storage:="_Customer", OtherKey:="CustomerID", ThisKey:="CustomerID", IsForeignKey:=True)> _
        Public Property Customer() As Customer
            Get
                Return Me._Customer.Entity
            End Get
            Set(ByVal value As Customer)
                If (Me._Customer.Entity IsNot value) Then

                    If (Me._Customer.Entity IsNot Nothing) Then
                        Dim temp As Customer = Me._Customer.Entity
                        Me._Customer.Entity = Nothing
                        temp.Orders.Remove(Me)
                    End If
                    Me._Customer.Entity = value
                    If (value IsNot Nothing) Then
                        value.Orders.Add(Me)
                    End If
                End If
            End Set
        End Property
    End Class
End Namespace