﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text

Namespace DatabaseComponent
    Partial Public Class Employee
        Partial Private Sub OnLastNameChanging(ByVal value As String)

        End Sub
        Private Sub OnLastNameChanging(ByVal value As String)
            If value.Length < 3 Then
                Throw New ArgumentException("' " + value + "' is too short. The last name must be three characters.")
            End If
        End Sub
    End Class
End Namespace