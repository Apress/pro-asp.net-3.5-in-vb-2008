﻿Imports System
Imports System.Data
Imports System.Data.Linq
Imports System.Data.SqlClient
Imports System.Data.Linq.Mapping

Namespace DatabaseComponent
    <Table(Name:="Employees")> _
    Public Class EmployeeDetails
        Private privateEmployeeID As Integer
        <Column(IsPrimaryKey:=True)> _
        Public Property EmployeeID() As Integer
            Get
                Return privateEmployeeID
            End Get
            Set(ByVal value As Integer)
                privateEmployeeID = value
            End Set
        End Property

        Private privateFirstName As String
        <Column()> _
        Public Property FirstName() As String
            Get
                Return privateFirstName
            End Get
            Set(ByVal value As String)
                privateFirstName = value
            End Set
        End Property

        Private privateLastName As String
        <Column()> _
        Public Property LastName() As String
            Get
                Return privateLastName
            End Get
            Set(ByVal value As String)
                privateLastName = value
            End Set
        End Property

        Private privateTitleOfCourtesy As String
        <Column()> _
        Public Property TitleOfCourtesy() As String
            Get
                Return privateTitleOfCourtesy
            End Get
            Set(ByVal value As String)
                privateTitleOfCourtesy = value
            End Set
        End Property

        Public Sub New(ByVal employeeID As Integer, ByVal firstName As String, ByVal lastName As String, ByVal titleOfCourtesy As String)
            Me.EmployeeID = employeeID
            Me.FirstName = firstName
            Me.LastName = lastName
            Me.TitleOfCourtesy = titleOfCourtesy
        End Sub

        Public Sub New()
        End Sub
    End Class

End Namespace