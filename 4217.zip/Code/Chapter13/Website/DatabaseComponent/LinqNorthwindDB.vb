﻿Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Data.Linq
Imports System.Web.Configuration
Imports System.Linq
Imports System.Data.SqlClient
Imports System.Xml.Linq

Namespace DatabaseComponent
    Public Class LinqNorthwindDB
        Private dataContext As DataContext

        Public Sub New()
            Me.New(WebConfigurationManager.ConnectionStrings("Northwind").ConnectionString)
        End Sub

        Public Sub New(ByVal connectionString As String)
            dataContext = New DataContext(connectionString)

            Dim loadOptions As New DataLoadOptions()
            loadOptions.LoadWith(Of Customer)(Function(customer) customer.Orders)

            ' Use these load options to retrieve only a subset of order records.
            'loadOptions.AssociateWith<Customer>(customer => 
            '     from order in customer.Orders where order.OrderDate > new DateTime(1998,1,1) select order);

            dataContext.LoadOptions = loadOptions
        End Sub

        Public Function GetEmployees() As IQueryable(Of EmployeeDetails)
            Return dataContext.GetTable(Of EmployeeDetails)()
        End Function

        Public Function GetEmployees(ByVal lastName As String) As List(Of EmployeeDetails)
            Dim matches As IEnumerable(Of EmployeeDetails) = _
             From employee In dataContext.GetTable(Of EmployeeDetails)() _
             Where employee.LastName = lastName _
             Select employee
            Try
                Return matches.ToList()
            Catch err As SqlException
                ' Replace the error with something less specific.
                ' You could also log the error now.
                Throw New ApplicationException("Data error.")
            End Try
        End Function

        Public Function GetEmployee(ByVal ID As Integer) As EmployeeDetails
            ' The no-expression appraoch.
            'return dataContext.GetTable<EmployeeDetails>()
            '    .Single(employee => employee.EmployeeID == ID);

            ' The LINQ expression approach.
            Dim matches = _
             From employee In dataContext.GetTable(Of EmployeeDetails)() _
             Where employee.EmployeeID = ID _
             Select employee
            Return matches.Single()
        End Function

        Public Function CountEmployees() As Integer
            Return dataContext.GetTable(Of EmployeeDetails)().Count()
        End Function

        Public Function GetCustomers() As List(Of Customer)
            ' The no-expression approach.
            'return db.GetTable<Customer>().ToList<Customer>();

            ' The LINQ expression approach.
            Dim matches = ( _
              From customer In dataContext.GetTable(Of Customer)() _
              Select customer)
            Return matches.ToList()
        End Function

        Public Function GetOrder(ByVal ID As Integer) As Order
            ' The no-expression approach.
            'Order or = dataContext.GetTable<Order>().Single<Order>(o => o.OrderID == ID);
            'return or;

            ' The LINQ expression approach.
            Dim matches = _
             From order In dataContext.GetTable(Of Order)() _
             Where order.OrderID = ID _
             Select order
            Return matches.Single()
        End Function
        Public Function GetEmployeeXml() As XDocument
            Dim doc As New XDocument(New XDeclaration("1.0", "utf-8", "yes"), New XElement("Employees", _
               From employee In dataContext.GetTable(Of EmployeeDetails)() _
               Select New XElement() {New XElement("Employee", New XAttribute("ID", employee.EmployeeID), New XElement("Name", employee.FirstName & " " & employee.LastName))}))
            Return doc
        End Function

    End Class
End Namespace