﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Xml.Linq
Imports System.Data.Linq
Imports DatabaseComponent.DatabaseComponent
Imports System.Web.Configuration

Partial Public Class Update
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim connectionString As String = WebConfigurationManager.ConnectionStrings("Northwind").ConnectionString
        Dim dataContext As New DataContext(connectionString)

        Dim employees As Table(Of EmployeeDetails) = dataContext.GetTable(Of EmployeeDetails)()
        employees.First().FirstName = "New Name"

        Dim newEmployee As New EmployeeDetails(342, "Rakesh", "Ramaranja", "Mr.")
        employees.InsertOnSubmit(newEmployee)

        Dim removedEmployee As EmployeeDetails = employees.Single(Function(employee) employee.EmployeeID = 3)
        employees.DeleteOnSubmit(removedEmployee)

        employees.DeleteAllOnSubmit(Of EmployeeDetails)( _
          From employee In employees _
          Where employee.LastName.StartsWith("F") _
          Select employee)

        Dim changes As ChangeSet = dataContext.GetChangeSet()
        gridModified.DataSource = changes.Updates
        gridAdded.DataSource = changes.Inserts
        gridRemoved.DataSource = changes.Deletes
        Me.DataBind()
    End Sub
End Class