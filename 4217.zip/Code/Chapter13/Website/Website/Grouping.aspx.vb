Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Collections.Generic
Imports DatabaseComponent.DatabaseComponent


Partial Public Class Grouping
    Inherits System.Web.UI.Page
    Private dbEmployee As New EmployeeDB()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim employees As List(Of EmployeeDetails) = dbEmployee.GetEmployees()


        Dim matches = _
From employee In employees _
Group employee By employee.TitleOfCourtesy Into g = Group _
Select New With {Key .Title = TitleOfCourtesy, Key .Employees = g.Count()}
        gridEmployees.DataSource = matches
        gridEmployees.DataBind()

        '      Dim price As Integer = 
        '      Dim value = From product In employees _
        'Group product By Convert.ToInt32(Products.UnitPrice) / 50) Into g = Group

        '      SelectIterator()
    End Sub
End Class