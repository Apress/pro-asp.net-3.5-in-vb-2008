﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Xml.Linq
Imports System.Collections.Generic
Imports DatabaseComponent.DatabaseComponent

Partial Public Class Projection
    Inherits System.Web.UI.Page
    Private db As New EmployeeDB()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim employees As List(Of EmployeeDetails) = db.GetEmployees()

        ' Anonymous type. 
        Dim matches = From employee In employees _
    Select First = employee.FirstName, Last = employee.LastName
        gridEmployees.DataSource = matches
        gridEmployees.DataBind()
    End Sub
End Class