﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports DatabaseComponent
Imports DatabaseComponent.DatabaseComponent
Imports System.Collections.Generic
Imports System.Linq

Partial Public Class IterativeVsDeclarative
    Inherits System.Web.UI.Page
    Private db As New EmployeeDB()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
    End Sub

    Protected Sub cmdForeach_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Get the full collection of employees from a helper method. 
        Dim employees As List(Of EmployeeDetails) = db.GetEmployees()

        ' Find the matching employees. 
        Dim matches As New List(Of EmployeeDetails)()
        For Each employee As EmployeeDetails In employees
            If employee.LastName.StartsWith("D") Then
                matches.Add(employee)
            End If
        Next

        gridEmployees.DataSource = matches
        gridEmployees.DataBind()
    End Sub

    Protected Sub cmdLinq_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim employees As List(Of EmployeeDetails) = db.GetEmployees()

        ' Implicit syntax. 
        Dim matches As IEnumerable(Of EmployeeDetails) = From employee In employees Where employee.LastName.StartsWith("D") Select employee
        gridEmployees.DataSource = matches
        gridEmployees.DataBind()

    End Sub
End Class