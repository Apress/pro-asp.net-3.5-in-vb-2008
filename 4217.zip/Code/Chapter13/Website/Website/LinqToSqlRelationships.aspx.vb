﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports DatabaseComponent.DatabaseComponent
Imports System.Text

Partial Public Class LinqToSqlRelationships
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim db As New LinqNorthwindDB()

        'Order ord = db.GetOrder(10643);
        'ord.OrderDate = DateTime.Now;     
        'Order ord2 = db.GetOrder(10643);

        Dim sb As New StringBuilder()
        For Each customer As DatabaseComponent.Customer In db.GetCustomers()
            sb.Append(customer.CompanyName)
            sb.Append("<br />")

            For Each order As DatabaseComponent.Order In customer.Orders
                sb.Append(order.OrderID.ToString())
                sb.Append(" - ")
                sb.Append(order.OrderDate.Value.ToShortDateString())
                sb.Append("<br />")
            Next order
            sb.Append("<hr /><br />")
        Next customer
        lblInfo.Text = sb.ToString()
    End Sub
End Class