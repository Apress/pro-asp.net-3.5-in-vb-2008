﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Xml.Linq

Partial Public Class LinqDataSourceTest
    Inherits System.Web.UI.Page
    
    Protected Sub detailEmployee_ItemDeleted(ByVal sender As Object, ByVal e As DetailsViewDeletedEventArgs) Handles detailsEmployee.ItemDeleted
        gridEmployees.SelectedIndex = -1
        gridEmployees.DataBind()
    End Sub

    Protected Sub detailEmployee_ModeChanged(ByVal sender As Object, ByVal e As EventArgs) Handles detailsEmployee.ModeChanged
        If detailsEmployee.CurrentMode = DetailsViewMode.Insert Then
            gridEmployees.SelectedIndex = -1
        End If
    End Sub
    Protected Sub detailsEmployee_ItemInserted(ByVal sender As Object, ByVal e As DetailsViewInsertedEventArgs) Handles detailsEmployee.ItemInserted
        If e.Exception IsNot Nothing Then
            Dim linqException As LinqDataSourceValidationException = TryCast(e.Exception, LinqDataSourceValidationException)
            If linqException Is Nothing Then
                lblError.Text = "Data error."
            Else
                lblError.Text = ""
                For Each err As Exception In linqException.InnerExceptions.Values
                    lblError.Text += err.Message + "<br />"
                Next
            End If

            e.ExceptionHandled = True
        Else
            gridEmployees.DataBind()
        End If
    End Sub
    Protected Sub detailsEmployee_ItemUpdated(ByVal sender As Object, ByVal e As DetailsViewUpdatedEventArgs) Handles detailsEmployee.ItemUpdated
        If e.Exception IsNot Nothing Then
            Dim linqException As LinqDataSourceValidationException = TryCast(e.Exception, LinqDataSourceValidationException)
            If linqException Is Nothing Then
                lblError.Text = "Data error."
            Else
                lblError.Text = ""
                For Each err As Exception In linqException.InnerExceptions.Values
                    lblError.Text += err.Message + "<br />"
                Next
            End If

            e.ExceptionHandled = True
        Else
            gridEmployees.DataBind()
        End If
    End Sub
    Protected Sub gridEmployees_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles gridEmployees.SelectedIndexChanged
        detailsEmployee.ChangeMode(DetailsViewMode.[ReadOnly])
    End Sub
End Class