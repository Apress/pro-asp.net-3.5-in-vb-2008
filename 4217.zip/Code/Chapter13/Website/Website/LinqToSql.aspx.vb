﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Linq
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports DatabaseComponent.DatabaseComponent
Imports System.Collections.Generic

Partial Public Class LinqToSql
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim db As New LinqNorthwindDB()
        Dim table As IQueryable(Of EmployeeDetails) = db.GetEmployees()
        Dim matches As IEnumerable(Of EmployeeDetails) = _
         From employee In table _
         Where employee.LastName.StartsWith("D") _
         Select employee

        grid.DataSource = matches
        grid.DataBind()
    End Sub
End Class