﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Web
Imports System.Security.Principal

Namespace BasicAuthMembershipProvider
    Public Class BasicAuthModule

#Region "member declarations"
        Public Const HttpAuthorizationHeader As String = "Authorization"  ' HTTP1.1 Authorization header
        Public Const HttpBasicSchemeName As String = "Basic" ' HTTP1.1 Basic Challenge Scheme Name
        Public Const HttpCredentialSeparator As Char = ":" ' HTTP1.1 Credential username and password separator
        Public Const HttpNotAuthorizedStatusCode As Integer = 401 ' HTTP1.1 Not authorized response status code
        Public Const HttpWWWAuthenticateHeader As String = "WWW-Authenticate" ' HTTP1.1 Basic Challenge Scheme Name
        Public Const Realm As String = "demo" ' HTTP.1.1 Basic Challenge Realm
#End Region
#Region "Main Event Processing Callbacks"
        Public Sub AuthenticateUser(ByVal source As Object, ByVal e As EventArgs)
            Dim application As HttpApplication = DirectCast(source, HttpApplication)
            Dim context As HttpContext = application.Context
            Dim userName As String = Nothing
            Dim password As String = Nothing
            Dim realm As String = Nothing
            Dim authorizationHeader As String = context.Request.Headers(HttpAuthorizationHeader)

            '
            '  Extract the basic authentication credentials from the request
            '
            If Not ExtractBasicCredentials(authorizationHeader, userName, password) Then
                Return
            End If


            '
            ' Validate the user credentials
            '
            If Not ValidateCredentials(userName, password, realm) Then
                Return
            End If

            '
            ' Create the user principal and associate it with the request
            '
            context.User = New GenericPrincipal(New GenericIdentity(userName), Nothing)
        End Sub

        Public Sub IssueAuthenticationChallenge(ByVal source As Object, ByVal e As EventArgs)
            Dim application As HttpApplication = DirectCast(source, HttpApplication)
            Dim context As HttpContext = application.Context

            '
            ' Issue a basic challenge if necessary
            '
            If context.Response.StatusCode = HttpNotAuthorizedStatusCode Then
                context.Response.AddHeader(HttpWWWAuthenticateHeader, "Basic realm =\"" + Realm + " \ "")
            End If
        End Sub
#End Region

#Region "Utility Methods"
        Protected Overridable Function ValidateCredentials(ByVal userName As String, ByVal password As String, ByVal realm As String) As Boolean
            '
            '  Validate the credentials using Membership (refault provider)
            '

            ' return Membership.ValidateUser(userName, password);
            If userName.Equals("test") And password.Equals("test") Then
                Return True
            Else
                return false
            End If
        End Function

        Protected Overridable Function ExtractBasicCredentials(ByVal authorizationHeader As String, ByRef username As String, ByRef password As String) As Boolean
            If authorizationHeader = Nothing Or authorizationHeader.Equals(String.Empty) Then
                Return False
            End If

            Dim verifiedAuthorizationHeader As String = authorizationHeader.Trim()

            If verifiedAuthorizationHeader.IndexOf(HttpBasicSchemeName) <> 0 Then
                Return False
            End If

            ' get the credential payload
            verifiedAuthorizationHeader = verifiedAuthorizationHeader.Substring(HttpBasicSchemeName.Length, verifiedAuthorizationHeader.Length - HttpBasicSchemeName.Length).Trim()

            ' decode the base 64 encodeded credential payload
            Dim credentialBase64DecodedArray As Byte() = Convert.FromBase64String(verifiedAuthorizationHeader)
            Dim encoding As UTF8Encoding = New UTF8Encoding()

            Dim decodedAuthorizationHeader As String = encoding.GetString(credentialBase64DecodedArray, 0, credentialBase64DecodedArray.Length)

            ' get the username, password, and realm
            Dim separatorPosition As Integer = decodedAuthorizationHeader.IndexOf(HttpCredentialSeparator)

            If separatorPosition <= 0 Then
                Return False
            End If
            username = decodedAuthorizationHeader.Substring(0, separatorPosition).Trim()
            password = decodedAuthorizationHeader.Substring(separatorPosition + 1, (decodedAuthorizationHeader.Length - separatorPosition - 1)).Trim()

            If username.Equals(String.Empty) Or password.Equals(String.Empty) Then
                Return False
            End If
            Return True
        End Function
#End Region

#Region "IHttpModule Members"
        Public Sub Init(ByVal context As HttpApplication)
            ' 
            ' Subscribe to the authenticate event to perform the 
            ' authentication.
            '
            AddHandler context.AuthenticateRequest, New EventHandler(AddressOf Me.AuthenticateUser)
            '
            ' Subscribe to the EndRequest event to issue the 
            ' challenge if necessary.
            ' 
            AddHandler context.EndRequest, New EventHandler(AddressOf Me.IssueAuthenticationChallenge)
        End Sub

        Public Sub Dispose()
            '
            ' Do nothing here
            '
        End Sub
#End Region

    End Class

End Namespace
