﻿
Partial Class Restricted_ChangePassword
    Inherits System.Web.UI.Page

End Class
