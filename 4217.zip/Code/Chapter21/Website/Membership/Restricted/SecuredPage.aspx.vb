﻿
Partial Class Restricted_SecuredPage
    Inherits System.Web.UI.Page

End Class
