﻿
Partial Class loginC
    Inherits System.Web.UI.Page

End Class
