﻿
Partial Class login
    Inherits System.Web.UI.Page

End Class
