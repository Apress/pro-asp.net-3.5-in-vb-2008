﻿
Partial Class PwdRecoverDefault
    Inherits System.Web.UI.Page

End Class
