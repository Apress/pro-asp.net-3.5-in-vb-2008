﻿
Partial Class RegisterEasy
    Inherits System.Web.UI.Page

End Class
