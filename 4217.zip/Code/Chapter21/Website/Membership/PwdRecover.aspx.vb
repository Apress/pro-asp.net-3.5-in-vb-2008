﻿
Partial Class PwdRecover
    Inherits System.Web.UI.Page

End Class
