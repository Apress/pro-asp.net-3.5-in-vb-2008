﻿Imports System.Diagnostics

Partial Class CreateUser
    Inherits System.Web.UI.Page

    Protected Sub ActionAddUser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ActionAddUser.Click
        Try
            Dim Status As MembershipCreateStatus
            Membership.CreateUser(UserNameText.Text, PasswordText.Text, UserEmailText.Text, PwdQuestionText.Text, PwdAnswerText.Text, True, Status)

            StatusLabel.Text = "User created successfully!"
        Catch ex As Exception
            Debug.WriteLine("Exception: " + ex.Message)
            StatusLabel.Text = "Unable to create user!"
        End Try
         
    End Sub
End Class
