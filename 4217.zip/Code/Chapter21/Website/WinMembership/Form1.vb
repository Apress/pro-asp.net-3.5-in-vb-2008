﻿Imports System.Web.Security
Public Class Form1
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim users As MembershipUserCollection = Membership.GetAllUsers()
        For Each user As MembershipUser In users
            Dim lvi As ListViewItem = New ListViewItem()
            lvi.Text = user.UserName
            lvi.SubItems.Add(user.Email)
            lvi.SubItems.Add(user.CreationDate.ToString())

            UsersListView.Items.Add(lvi)
        Next
    End Sub

    Private Sub AddCommand_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddCommand.Click
        Try
            Membership.CreateUser(UserNameText.Text, PasswordText.Text, EmailText.Text)
            MessageBox.Show("User created!")
        Catch ex As Exception
            MessageBox.Show("Unable to create user: " + ex.Message)
        End Try
    End Sub
End Class
