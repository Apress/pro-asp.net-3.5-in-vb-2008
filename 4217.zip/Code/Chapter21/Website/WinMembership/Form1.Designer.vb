﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Text = "Form1"

        Me.EmailText = New System.Windows.Forms.TextBox
        Me.PasswordText = New System.Windows.Forms.TextBox
        Me.UserNameText = New System.Windows.Forms.TextBox
        Me.UsersListView = New System.Windows.Forms.ListView
        Me.columnHeader1 = New System.Windows.Forms.ColumnHeader
        Me.columnHeader2 = New System.Windows.Forms.ColumnHeader
        Me.columnHeader3 = New System.Windows.Forms.ColumnHeader
        Me.AddCommand = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'EmailText
        '
        Me.EmailText.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.EmailText.Location = New System.Drawing.Point(353, 218)
        Me.EmailText.Name = "EmailText"
        Me.EmailText.Size = New System.Drawing.Size(162, 20)
        Me.EmailText.TabIndex = 8
        '
        'PasswordText
        '
        Me.PasswordText.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PasswordText.Location = New System.Drawing.Point(247, 218)
        Me.PasswordText.Name = "PasswordText"
        Me.PasswordText.Size = New System.Drawing.Size(100, 20)
        Me.PasswordText.TabIndex = 7
        '
        'UserNameText
        '
        Me.UserNameText.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UserNameText.Location = New System.Drawing.Point(13, 218)
        Me.UserNameText.Name = "UserNameText"
        Me.UserNameText.Size = New System.Drawing.Size(228, 20)
        Me.UserNameText.TabIndex = 6
        '
        'UsersListView
        '
        Me.UsersListView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.UsersListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.columnHeader1, Me.columnHeader2, Me.columnHeader3})
        Me.UsersListView.Location = New System.Drawing.Point(13, 11)
        Me.UsersListView.Name = "UsersListView"
        Me.UsersListView.Size = New System.Drawing.Size(583, 199)
        Me.UsersListView.TabIndex = 5
        Me.UsersListView.UseCompatibleStateImageBehavior = False
        Me.UsersListView.View = System.Windows.Forms.View.Details
        '
        'columnHeader1
        '
        Me.columnHeader1.Text = "Name"
        Me.columnHeader1.Width = 156
        '
        'columnHeader2
        '
        Me.columnHeader2.Text = "Email"
        Me.columnHeader2.Width = 271
        '
        'columnHeader3
        '
        Me.columnHeader3.Text = "Created"
        Me.columnHeader3.Width = 129
        '
        'AddCommand
        '
        Me.AddCommand.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AddCommand.Location = New System.Drawing.Point(521, 216)
        Me.AddCommand.Name = "AddCommand"
        Me.AddCommand.Size = New System.Drawing.Size(75, 23)
        Me.AddCommand.TabIndex = 9
        Me.AddCommand.Text = "Add User"
        Me.AddCommand.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(609, 251)
        Me.Controls.Add(Me.EmailText)
        Me.Controls.Add(Me.PasswordText)
        Me.Controls.Add(Me.UserNameText)
        Me.Controls.Add(Me.UsersListView)
        Me.Controls.Add(Me.AddCommand)
        Me.Name = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents EmailText As System.Windows.Forms.TextBox
    Private WithEvents PasswordText As System.Windows.Forms.TextBox
    Private WithEvents UserNameText As System.Windows.Forms.TextBox
    Private WithEvents UsersListView As System.Windows.Forms.ListView
    Private WithEvents columnHeader1 As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeader2 As System.Windows.Forms.ColumnHeader
    Private WithEvents columnHeader3 As System.Windows.Forms.ColumnHeader
    Private WithEvents AddCommand As System.Windows.Forms.Button
End Class
