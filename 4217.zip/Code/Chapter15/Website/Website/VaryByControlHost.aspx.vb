
Partial Class VaryByControlHost
    Inherits System.Web.UI.Page

End Class
