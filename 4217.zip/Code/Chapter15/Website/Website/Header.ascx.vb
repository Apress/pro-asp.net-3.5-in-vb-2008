
Partial Class Header
    Inherits System.Web.UI.UserControl

End Class
