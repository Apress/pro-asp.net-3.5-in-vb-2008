
Partial Class TimeDisplayHost
    Inherits System.Web.UI.Page

End Class
