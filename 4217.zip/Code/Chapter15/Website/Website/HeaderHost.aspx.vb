
Partial Class HeaderHost
    Inherits System.Web.UI.Page

End Class
