﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls

<Serializable()> _
Public Class Address
    Public Property Name() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Property Street() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Property City() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Property ZipCode() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Property State() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Property Country() As String
        Get
        End Get
        Set(ByVal value As String)
        End Set
    End Property

    Public Sub New(ByVal name As String, ByVal street As String, ByVal city As String, ByVal zipCode As String, ByVal state As String, ByVal country As String)
        Name = name
        Street = street
        City = city
        ZipCode = zipCode
        State = state
        Country = country
    End Sub

    Public Sub New()
    End Sub
End Class