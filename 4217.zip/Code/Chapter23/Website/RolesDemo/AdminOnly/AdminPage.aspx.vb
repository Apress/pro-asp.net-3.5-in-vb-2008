﻿
Partial Class AdminOnly_AdminPage
    Inherits System.Web.UI.Page

End Class
