﻿
Partial Class LoginView
    Inherits System.Web.UI.Page

End Class
