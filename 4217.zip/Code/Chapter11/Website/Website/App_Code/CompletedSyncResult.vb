﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Threading


Public Class CompletedSyncResult
    Implements IAsyncResult
    Private m_operationException As Exception
    Public Property OperationException() As Exception
        Get
            Return m_operationException
        End Get
        Set(ByVal value As Exception)
            m_operationException = value
        End Set
    End Property

    Private m_result As DataTable
    Public Property Result() As DataTable
        Get
            If OperationException IsNot Nothing Then
                Throw OperationException
            End If
            Return m_result
        End Get
        Set(ByVal value As DataTable)
            m_result = value
        End Set
    End Property

    ' Use in the case of data being ready. 
    Public Sub New(ByVal result As DataTable, ByVal asyncCallback As AsyncCallback, ByVal asyncState As Object)
        state = asyncState
        Result = result

        ' Code that triggers the callback, if it's used. 
        asyncCallback(Me)
    End Sub

    ' Use in the case of error. 
    Public Sub New(ByVal operationException As Exception, ByVal asyncCallback As AsyncCallback, ByVal asyncState As Object)
        state = asyncState
        OperationException = operationException

        ' Code that triggers the callback, if it's used. 
        asyncCallback(Me)
    End Sub

    Private state As Object
    Private ReadOnly Property AsyncState() As Object Implements IAsyncResult.AsyncState
        Get
            Return state
        End Get
    End Property

    Private ReadOnly Property AsyncWaitHandle() As WaitHandle Implements IAsyncResult.AsyncWaitHandle
        Get
            Return Nothing
        End Get
    End Property

    Private ReadOnly Property CompletedSynchronously() As Boolean Implements IAsyncResult.CompletedSynchronously
        Get
            Return True
        End Get
    End Property

    Private ReadOnly Property IsCompleted() As Boolean Implements IAsyncResult.IsCompleted
        Get
            Return True
        End Get
    End Property
End Class