﻿Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Imports System.Web.Configuration

Partial Public Class AsyncDataReaderRefactored
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        ' Register the asynchronous methods for later use. 
        ' This method returns immediately. 
        Page.AddOnPreRenderCompleteAsync(AddressOf BeginTask, AddressOf EndTask)
    End Sub

    ' The ADO.NET objects need to be accessible in several different 
    ' event handlers, so they must be declared as member variables. 
    Private con As SqlConnection
    Private cmd As SqlCommand

    Private Function BeginTask(ByVal sender As Object, ByVal e As EventArgs, ByVal cb As AsyncCallback, ByVal state As Object) As IAsyncResult
        ' Check the cache. 
        If Cache("Employees") IsNot Nothing Then
            Return New AsyncQueryResult(DirectCast(Cache("Employees"), DataTable), cb, state)
        End If

        ' Create the command. 
        Dim connectionString As String = WebConfigurationManager.ConnectionStrings("NorthwindAsync").ConnectionString
        con = New SqlConnection(connectionString)
        cmd = New SqlCommand("SELECT * FROM Employees", con)

        Return New AsyncQueryResult(cmd, cb, state)
    End Function

    Private table As DataTable

    ' This method fires when IAsyncResult indicates the task is complete. 
    Private Sub EndTask(ByVal ar As IAsyncResult)
        Dim completedSync As AsyncQueryResult = DirectCast(ar, AsyncQueryResult)

        Try
            table = completedSync.Result

            ' Store it in the cache, if needed. 
            If Not ar.CompletedSynchronously Then
                Cache.Insert("Employees", table, Nothing, DateTime.Now.AddMinutes(5), TimeSpan.Zero)
            End If
        Catch err As Exception
            lblError.Text = "An error occurred. <br />"

            ' Typically, you wouldn't display the underlying 
            ' error message. 
            ' This is a debugging/testing aid. 
            lblError.Text += err.Message
        End Try
    End Sub


    ' Perform the data binding in the next stage of the page lifecycle. 
    Protected Sub Page_PreRenderComplete(ByVal sender As Object, ByVal e As EventArgs)
        grid.DataSource = table
        grid.DataBind()
    End Sub

    ' Make sure the connection is closed in the event of an error. 
    Public Overloads Overrides Sub Dispose()
        If con IsNot Nothing Then
            con.Close()
        End If
        MyBase.Dispose()
    End Sub

End Class