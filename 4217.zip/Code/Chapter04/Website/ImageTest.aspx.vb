﻿Partial Class ImageTest
    Inherits System.Web.UI.Page

    Protected Sub ImageButton1_Click(ByVal sender As Object, _
    ByVal e As System.Web.UI.ImageClickEventArgs) _
    Handles ImageButton1.Click
        lblResult.Text = "You clicked at (" + e.X.ToString() + ", " + _
        e.Y.ToString() + "). "

        If (e.Y < 100) AndAlso (e.Y > 20) AndAlso _
        (e.X > 20) AndAlso (e.X < 275) Then
            lblResult.Text += "You clicked on the button surface."
        Else
            lblResult.Text += "You clicked the button border."
        End If
    End Sub
End Class
