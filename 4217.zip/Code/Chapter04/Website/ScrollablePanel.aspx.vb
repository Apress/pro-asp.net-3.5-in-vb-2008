﻿Partial Class ScrollablePanel
    Inherits System.Web.UI.Page

End Class
