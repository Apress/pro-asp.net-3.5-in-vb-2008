
Partial Class XmlDataSourceTreeView1
    Inherits System.Web.UI.Page

End Class
