Imports System.Linq
Imports System.Xml.Linq
Imports System.Collections

Partial Class LinqToXml
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        WriteXml()
        ReadXml()
    End Sub

    Private Sub WriteXml()
        Dim doc As New XDocument(New XDeclaration("1.0", "utf-8", "yes"), New XComment("Created: " + DateTime.Now.ToString()), _
        New XElement("DvdList", _
        New XElement("DVD", _
        New XAttribute("Category", "Science Fiction"), _
        New XElement("Title", "The Matrix"), _
        New XElement("Director", "arry Wachowski"), _
        New XElement("Price", "18.74"), _
        New XElement("Starring", _
            New XElement("Star", "Keanu Reeves"), _
            New XElement("Star", "Laurence Fishburne") _
        ) _
      ), _
         New XElement("DVD", _
                  New XAttribute("ID", "2"), _
                  New XAttribute("Category", "Drama"), _
                  New XElement("Title", "Forrest Gump"), _
                  New XElement("Director", "Robert Zemeckis"), _
                  New XElement("Price", "23.99"), _
                  New XElement("Starring", _
                      New XElement("Star", "Tom Hanks"), _
                      New XElement("Star", "Robin Wright") _
                  ) _
              ), _
              New XElement("DVD", _
                  New XAttribute("ID", "3"), _
                  New XAttribute("Category", "Horror"), _
                  New XElement("Title", "The Others"), _
                  New XElement("Director", "Alejandro Amen�bar"), _
                  New XElement("Price", "22.49"), _
                  New XElement("Starring", _
                      New XElement("Star", "Nicole Kidman"), _
                      New XElement("Star", "Christopher Eccleston") _
                  ) _
              ), _
              New XElement("DVD", _
                  New XAttribute("ID", "4"), _
                  New XAttribute("Category", "Mystery"), _
                  New XElement("Title", "Mulholland Drive"), _
                  New XElement("Director", "David Lynch"), _
                  New XElement("Price", "25.74"), _
                  New XElement("Starring", _
                      New XElement("Star", "Laura Harring") _
                  ) _
              ), _
              New XElement("DVD", _
                  New XAttribute("ID", "5"), _
                  New XAttribute("Category", "Science Fiction"), _
                  New XElement("Title", "A.I. Artificial Intelligence"), _
                  New XElement("Director", "Steven Spielberg"), _
                  New XElement("Price", "23.99"), _
                  New XElement("Starring", _
                      New XElement("Star", "Haley Joel Osment"), _
                      New XElement("Star", "Jude Law") _
                  ) _
              ) _
           ) _
        )
        doc.Save(Server.MapPath("DvdList2.xml"))
    End Sub

    Private Sub ReadXml()
        'Create the reader.
        Dim xmlFile As String = Server.MapPath("DvdList2.xml")
        Dim doc As XDocument = XDocument.Load(xmlFile)
        Dim str As New StringBuilder()
        For Each element As XElement In doc.Element("DvdList").Elements()
            str.Append("<ul><b>")
            str.Append(element.Element("Title"))
            str.Append("</b><li>")
            str.Append(element.Element("Director"))
            str.Append("</li><li>")
            str.Append(String.Format("{0:C}", element.Element("Price")))
            str.Append("</li><ul>")
        Next

        lblXml.Text = str.ToString()
    End Sub
End Class
