
Partial Class XmlDataSourceTemplate
    Inherits System.Web.UI.Page

End Class
