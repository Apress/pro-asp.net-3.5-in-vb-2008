
Partial Class XmlControlTest
    Inherits System.Web.UI.Page

End Class
