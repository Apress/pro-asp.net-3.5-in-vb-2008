
Partial Class XmlDataSourceXSLT
    Inherits System.Web.UI.Page

End Class
