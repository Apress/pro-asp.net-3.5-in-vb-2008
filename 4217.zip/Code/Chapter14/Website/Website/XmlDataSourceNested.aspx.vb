
Partial Class XmlDataSourceNested
    Inherits System.Web.UI.Page

End Class
