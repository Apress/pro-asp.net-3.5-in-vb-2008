
Partial Class XmlDataSourceXPath
    Inherits System.Web.UI.Page

End Class
