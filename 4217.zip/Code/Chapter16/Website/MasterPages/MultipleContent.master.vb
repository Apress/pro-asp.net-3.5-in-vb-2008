﻿
Partial Class MasterPages_MultipleContent
    Inherits System.Web.UI.MasterPage
End Class

