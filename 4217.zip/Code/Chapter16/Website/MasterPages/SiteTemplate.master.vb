﻿
Partial Class MasterPages_SiteTemplate
    Inherits System.Web.UI.MasterPage
End Class

