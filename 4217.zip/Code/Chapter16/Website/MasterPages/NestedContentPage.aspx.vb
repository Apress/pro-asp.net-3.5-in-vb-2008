﻿
Partial Class MasterPages_NestedContentPage
    Inherits System.Web.UI.Page

End Class
