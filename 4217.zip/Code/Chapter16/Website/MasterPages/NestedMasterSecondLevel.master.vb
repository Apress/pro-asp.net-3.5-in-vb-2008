﻿
Partial Class MasterPages_NestedMasterSecondLevel
    Inherits System.Web.UI.MasterPage
End Class

