﻿
Partial Class MasterPages_SimpleContentPage
    Inherits System.Web.UI.Page

End Class
