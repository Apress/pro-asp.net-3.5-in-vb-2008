﻿
Partial Class MasterPages_MultipleContentPage
    Inherits System.Web.UI.Page

End Class
