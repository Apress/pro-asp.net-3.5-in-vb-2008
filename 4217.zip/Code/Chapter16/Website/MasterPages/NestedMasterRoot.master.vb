﻿
Partial Class MasterPages_NestedMasterRoot
    Inherits System.Web.UI.MasterPage
End Class

