﻿
Partial Class MasterPages_DefaultContent
    Inherits System.Web.UI.MasterPage
End Class

