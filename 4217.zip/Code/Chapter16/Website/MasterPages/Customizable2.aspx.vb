﻿
Partial Class MasterPages_Customizable2
    Inherits System.Web.UI.Page

End Class
