﻿
Partial Class MasterPages_DefaultContentPage
    Inherits System.Web.UI.Page

End Class
