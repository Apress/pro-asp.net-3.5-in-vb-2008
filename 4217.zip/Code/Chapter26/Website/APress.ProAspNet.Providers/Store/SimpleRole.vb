﻿Imports System
Imports System.Text
Imports System.Collections.Specialized

Namespace APress.ProAspNet.Providers.Store
    Public Class SimpleRole
        Public RoleName As String = ""
        Public AssignedUsers As New StringCollection()
    End Class
End Namespace
