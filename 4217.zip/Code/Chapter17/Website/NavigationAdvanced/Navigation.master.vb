
Partial Class Navigation
    Inherits System.Web.UI.MasterPage
End Class

