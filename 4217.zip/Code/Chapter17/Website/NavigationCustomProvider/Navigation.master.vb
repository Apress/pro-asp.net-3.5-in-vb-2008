
Partial Class NavigationCustomProvider_Navigation
    Inherits System.Web.UI.MasterPage
End Class

