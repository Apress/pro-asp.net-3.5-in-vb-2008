
Partial Class NavigationCustomProvider_Default
    Inherits System.Web.UI.Page

End Class
