
Partial Class NavigationBasic_Navigation
    Inherits System.Web.UI.MasterPage
End Class

