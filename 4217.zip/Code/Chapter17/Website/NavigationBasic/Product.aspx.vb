
Partial Class NavigationBasic_Product
    Inherits System.Web.UI.Page

End Class
