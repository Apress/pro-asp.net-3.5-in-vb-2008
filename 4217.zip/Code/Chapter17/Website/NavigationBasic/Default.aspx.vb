
Partial Class NavigationBasic_Default
    Inherits System.Web.UI.Page

End Class
