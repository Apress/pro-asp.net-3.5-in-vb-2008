Imports System.Data
Imports System.Configuration

Partial Class ObjectDataSourceParameters
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub sourceEmployee_Selecting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.ObjectDataSourceSelectingEventArgs) Handles sourceEmployee.Selecting
        If e.InputParameters("employeeID") Is Nothing Then
            e.Cancel = True
        End If
    End Sub
End Class
