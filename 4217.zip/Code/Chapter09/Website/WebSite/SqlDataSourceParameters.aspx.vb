
Partial Class SqlDataSourceParameters
    Inherits System.Web.UI.Page

End Class
