
Partial Class ObjectDataSourceUpdate
    Inherits System.Web.UI.Page

End Class
