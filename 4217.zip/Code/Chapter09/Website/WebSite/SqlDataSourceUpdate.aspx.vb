
Partial Class SqlDataSourceUpdate
    Inherits System.Web.UI.Page

End Class
