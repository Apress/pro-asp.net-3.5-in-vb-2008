
Partial Class ObjectDataSourceSimple
    Inherits System.Web.UI.Page

End Class
